"use client";

import { useEffect, useState } from "react";

/**
 * Единый источник задержки для всех виджетов страницы.
 * module-level store: все подписчики получают ОДНО и то же значение
 * (раньше auth-card и features крутили независимые интервалы и показывали
 * разные числа одновременно).
 */

let current = 12;
const subscribers = new Set<(v: number) => void>();
let timer: ReturnType<typeof setInterval> | null = null;

function start() {
  if (timer) return;
  timer = setInterval(() => {
    current = 9 + Math.floor(Math.random() * 7);
    for (const fn of subscribers) fn(current);
  }, 1800);
}

export function useLatency(): number {
  const [value, setValue] = useState(current);

  useEffect(() => {
    subscribers.add(setValue);
    start();
    return () => {
      subscribers.delete(setValue);
    };
  }, []);

  return value;
}
