"use client";

import { useLatency } from "@/hooks/use-latency";

/**
 * Живой статус-чип в строке бренда: «8/8 бирж онлайн · N мс».
 * Раньше значение было захардкожено и рассинхронизировалось
 * с остальными виджетами задержки на странице.
 */
export function LiveStatusChip() {
  const latency = useLatency();
  return (
    <div className="ml-auto hidden items-center gap-2 rounded-full border border-emerald-400/20 bg-emerald-400/5 px-3 py-1 font-mono text-[10.5px] text-slate-400 sm:flex">
      <i className="cp-dot-blink h-1.5 w-1.5 rounded-full bg-emerald-400" />
      8/8 бирж онлайн · <span className="text-emerald-400">{latency} мс</span>
    </div>
  );
}
