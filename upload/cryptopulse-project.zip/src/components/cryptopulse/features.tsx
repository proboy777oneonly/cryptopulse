"use client";

import { useEffect, useRef, useState } from "react";
import { BellRing, Zap, Building2, Activity } from "lucide-react";
import { useLatency } from "@/hooks/use-latency";

/* ================= Живые плитки фич ================= */

interface ArbQuote {
  coin: string;
  type: string;
  from: string;
  to: string;
  spread: number;
}

const INITIAL_ARBS: ArbQuote[] = [
  { coin: "BTC", type: "F-S", from: "BINANCE", to: "BYBIT", spread: 0.42 },
  { coin: "ETH", type: "F-F", from: "OKX", to: "GATE", spread: 0.18 },
  { coin: "SOL", type: "S-F", from: "BITGET", to: "KUCOIN", spread: 0.31 },
];

function useAnimatedNumber(target: number, decimals: number, duration = 1400) {
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);
  useEffect(() => {
    if (started.current) return;
    started.current = true;
    const el = ref.current;
    if (!el) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const dur = reduced ? 0 : duration;
    const t0 = performance.now();
    let raf = 0;
    const frame = (t: number) => {
      const p = Math.min(1, (t - t0) / (dur || 1));
      const e = 1 - Math.pow(1 - p, 3);
      el.textContent = (target * e).toFixed(decimals).replace(".", ",");
      if (p < 1) raf = requestAnimationFrame(frame);
      else el.textContent = target.toFixed(decimals).replace(".", ",");
    };
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, [target, decimals, duration]);
  return ref;
}

function Tile({
  icon,
  title,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="cp-fade-up flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.04] p-3 backdrop-blur-xl transition-all duration-300 hover:-translate-y-0.5 hover:border-violet-500/40 hover:shadow-[0_10px_35px_-10px_rgba(139,92,246,0.4)] sm:p-3.5">
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg border border-violet-500/30 bg-violet-500/15">
        {icon}
      </span>
      <div className="min-w-0">
        <div className="text-[12.5px] font-bold">{title}</div>
        <div className="overflow-hidden text-ellipsis">{children}</div>
      </div>
    </div>
  );
}

export function FeatureTiles() {
  const [arbs, setArbs] = useState(INITIAL_ARBS);
  const latency = useLatency();

  useEffect(() => {
    const id = setInterval(() => {
      setArbs((prev) =>
        prev.map((a) => ({
          ...a,
          spread: Math.max(0.04, +(a.spread + (Math.random() - 0.5) * 0.12).toFixed(2)),
        })),
      );
    }, 2100);
    return () => clearInterval(id);
  }, []);

  const alertsRef = useAnimatedNumber(0.8, 1);
  const best = arbs.reduce((a, b) => (b.spread > a.spread ? b : a));

  return (
    <div className="grid gap-3 sm:grid-cols-3">
      <Tile
        icon={<BellRing className="h-4 w-4 text-violet-300" />}
        title="Свечные алерты"
      >
        <div className="font-mono text-sm font-bold text-emerald-400">
          <span ref={alertsRef}>0,0</span> с
          <span className="ml-1.5 text-[10.5px] font-medium text-slate-500">задержка</span>
        </div>
      </Tile>

      <Tile icon={<Zap className="h-4 w-4 text-violet-300" />} title="Арбитраж live">
        <div className="flex items-center gap-1.5 font-mono text-sm font-bold whitespace-nowrap">
          <span className="text-slate-100">{best.coin}</span>
          <span className="rounded bg-cyan-400/10 px-1 py-px text-[9px] font-semibold text-cyan-300">
            {best.type}
          </span>
          <span className="text-emerald-400 transition-colors">
            +{best.spread.toFixed(2)}%
          </span>
          <span className="text-[10.5px] font-medium text-slate-500">
            {best.from}→{best.to}
          </span>
        </div>
      </Tile>

      <Tile
        icon={<Building2 className="h-4 w-4 text-violet-300" />}
        title="8 бирж · 24/7"
      >
        <div className="font-mono text-sm font-bold whitespace-nowrap text-slate-100">
          фьючерсы и спот
          <span className="ml-1.5 text-[10.5px] font-medium text-emerald-400">
            {latency} мс
          </span>
        </div>
      </Tile>
    </div>
  );
}

/* ================= Компактная лента бирж ================= */

export function ExchangeMarquee() {
  const exch: Array<[string, string]> = [
    ["BINANCE", "#f0b90b"],
    ["BYBIT", "#f7a600"],
    ["OKX", "#e8eaf6"],
    ["GATE", "#22c3f7"],
    ["BITGET", "#00f0ff"],
    ["KUCOIN", "#24ae8f"],
    ["HYPERLIQUID", "#97fce4"],
    ["ASTER", "#7c5cff"],
  ];
  const set = (
    <div className="flex items-center" aria-hidden="true">
      {exch.map(([name, color]) => (
        <span
          key={name}
          className="mr-4 inline-flex cursor-default items-center gap-2 rounded-lg border border-white/10 bg-white/[0.03] px-3 py-1.5 font-mono text-[11px] font-semibold tracking-wide text-slate-300 transition-colors hover:border-violet-500/50 hover:bg-violet-500/10"
        >
          <i className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: color }} />
          {name}
        </span>
      ))}
    </div>
  );
  return (
    <section
      aria-label="Подключённые биржи"
      className="relative z-10 border-t border-white/10 py-3"
    >
      <div className="mx-auto flex max-w-6xl items-center gap-4 px-6">
        <div className="flex shrink-0 items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.18em] text-slate-500">
          <Activity className="h-3.5 w-3.5 text-violet-400" />
          Биржи
        </div>
        <div className="cp-marquee cp-mask-x flex-1 overflow-hidden">
          <div
            className="cp-marquee-track"
            style={{ "--cp-marquee-duration": "30s" } as React.CSSProperties}
          >
            {set}
            {set}
          </div>
        </div>
      </div>
    </section>
  );
}
