"use client";

import { useEffect, useState } from "react";

interface Quote {
  sym: string;
  price: number;
  chg: number;
  dir: 0 | 1 | -1;
}

const INITIAL: Quote[] = [
  { sym: "BTC", price: 67240, chg: 1.24, dir: 1 },
  { sym: "ETH", price: 3512, chg: -0.42, dir: -1 },
  { sym: "SOL", price: 172.4, chg: 2.18, dir: 1 },
  { sym: "TON", price: 7.24, chg: 0.86, dir: 1 },
  { sym: "XRP", price: 0.6212, chg: -1.05, dir: -1 },
  { sym: "DOGE", price: 0.1584, chg: 0.44, dir: 1 },
  { sym: "AVAX", price: 42.1, chg: -0.68, dir: -1 },
  { sym: "LINK", price: 18.6, chg: 1.62, dir: 1 },
];

export function fmtPrice(v: number): string {
  if (v >= 1000)
    return Math.round(v)
      .toString()
      .replace(/\B(?=(\d{3})+(?!\d))/g, "\u2009");
  if (v >= 10) return v.toFixed(2);
  return v.toFixed(4);
}

const priceCls = (dir: 0 | 1 | -1) =>
  dir === 1
    ? "text-emerald-400"
    : dir === -1
      ? "text-rose-400"
      : "text-slate-400";

function TickerSet({ quotes }: { quotes: Quote[] }) {
  return (
    <div className="flex items-center" aria-hidden="true">
      {quotes.map((q) => (
        <span
          key={q.sym}
          className="inline-flex items-center gap-2 mr-9 whitespace-nowrap text-[12.5px]"
        >
          <span className="font-semibold text-slate-100">{q.sym}</span>
          <span className={`font-mono transition-colors duration-700 ${priceCls(q.dir)}`}>
            {fmtPrice(q.price)}
          </span>
          <span
            className={`font-mono text-[11.5px] ${
              q.chg >= 0 ? "text-emerald-400" : "text-rose-400"
            }`}
          >
            {q.chg >= 0 ? "+" : ""}
            {q.chg.toFixed(2)}%
          </span>
        </span>
      ))}
    </div>
  );
}

function MoscowClock() {
  const [time, setTime] = useState("--:--:--");
  useEffect(() => {
    const fmt = new Intl.DateTimeFormat("ru-RU", {
      timeZone: "Europe/Moscow",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false,
    });
    const update = () => setTime(fmt.format(new Date()));
    update();
    const id = setInterval(update, 1000);
    return () => clearInterval(id);
  }, []);
  return (
    <span className="flex h-full shrink-0 items-center gap-2 border-l border-white/10 px-3 font-mono text-[11px] tabular-nums text-slate-400">
      <span className="text-[9px] font-semibold tracking-[0.14em] text-violet-300">МСК</span>
      {time}
    </span>
  );
}

export function TickerTape() {
  const [quotes, setQuotes] = useState(INITIAL);

  useEffect(() => {
    const id = setInterval(() => {
      setQuotes((prev) =>
        prev.map((q) => {
          const drift = (Math.random() - 0.5) * 0.0014;
          const price = q.price * (1 + drift);
          return {
            ...q,
            price,
            dir: price > q.price ? 1 : price < q.price ? -1 : 0,
            chg: Math.max(-4, Math.min(4, q.chg + (Math.random() - 0.5) * 0.14)),
          };
        }),
      );
    }, 2400);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="relative z-10 flex h-10 items-stretch border-b border-white/10 bg-[#080a18]/85 backdrop-blur-md">
      <div className="flex items-center gap-2 px-4 shrink-0 border-r border-white/10 bg-gradient-to-r from-violet-600/25 to-violet-600/5">
        <span className="cp-dot-live h-2 w-2 rounded-full bg-emerald-400" />
        <span className="text-[11px] font-semibold tracking-[0.14em] text-violet-300">
          LIVE ПОТОК
        </span>
      </div>
      <div
        className="cp-marquee cp-mask-x flex-1 overflow-hidden"
        role="marquee"
        aria-label="Котировки в реальном времени"
      >
        <div
          className="cp-marquee-track"
          style={{ "--cp-marquee-duration": "38s" } as React.CSSProperties}
        >
          <TickerSet quotes={quotes} />
          <TickerSet quotes={quotes} />
        </div>
      </div>
      <MoscowClock />
    </div>
  );
}
