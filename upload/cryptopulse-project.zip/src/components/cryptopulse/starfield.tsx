"use client";

import { useEffect, useRef } from "react";

interface Star {
  x: number;
  y: number;
  z: number;
  r: number;
  tw: number;
}

export function Starfield() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let stars: Star[] = [];
    let raf = 0;
    let mx = 0;
    let my = 0;
    let tx = 0;
    let ty = 0;

    const init = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.min(170, Math.floor(window.innerWidth / 8));
      stars = Array.from({ length: count }, () => ({
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        z: Math.random() * 0.8 + 0.2,
        r: Math.random() * 1.2 + 0.3,
        tw: Math.random() * Math.PI * 2,
      }));
    };

    const onResize = () => {
      init();
      if (reduced) render(0);
    };

    const onMove = (e: MouseEvent) => {
      tx = (e.clientX / window.innerWidth - 0.5) * 26;
      ty = (e.clientY / window.innerHeight - 0.5) * 26;
    };

    const loop = (t: number) => {
      mx += (tx - mx) * 0.04;
      my += (ty - my) * 0.04;
      render(t);
      raf = requestAnimationFrame(loop);
    };

    const render = (t: number) => {
      ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
      for (const s of stars) {
        if (!reduced) {
          s.y += s.z * 0.1;
          s.x += s.z * 0.04;
          if (s.y > window.innerHeight) s.y = -2;
          if (s.x > window.innerWidth) s.x = -2;
        }
        const a = 0.25 + 0.75 * Math.abs(Math.sin(t / 1400 + s.tw));
        ctx.globalAlpha = a * s.z;
        ctx.fillStyle = "#cdd3ff";
        ctx.beginPath();
        ctx.arc(s.x + mx * s.z, s.y + my * s.z, s.r * s.z, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    };

    init();
    if (!reduced) window.addEventListener("mousemove", onMove);
    window.addEventListener("resize", onResize);
    /* при reduced-motion рисуем ОДИН статичный кадр — без бесконечного rAF-цикла */
    if (reduced) render(0);
    else raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("resize", onResize);
    };
  }, []);

  return (
    <>
      <canvas
        ref={canvasRef}
        aria-hidden="true"
        className="fixed inset-0 z-0 pointer-events-none"
      />
      <div aria-hidden="true" className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
        <div className="cp-aurora cp-aurora-1 w-[520px] h-[520px] bg-violet-600/25 -top-40 -left-32" />
        <div className="cp-aurora cp-aurora-2 w-[460px] h-[460px] bg-cyan-500/15 -bottom-36 -right-28" />
        <div className="cp-aurora cp-aurora-3 w-[380px] h-[380px] bg-fuchsia-500/10 top-[38%] left-[42%]" />
      </div>
    </>
  );
}
