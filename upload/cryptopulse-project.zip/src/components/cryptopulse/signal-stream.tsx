"use client";

import { useEffect, useState } from "react";
import { BarChart3, Volume2, ArrowLeftRight, TrendingUp } from "lucide-react";

type SigKind = "candle" | "vol" | "arb" | "break";

interface Sig {
  id: number;
  kind: SigKind;
  text: string;
  time: string;
}

const COINS = ["BTC", "ETH", "SOL", "TON", "XRP", "DOGE", "AVAX", "LINK"];
const EXS = ["BINANCE", "BYBIT", "OKX", "GATE", "BITGET", "KUCOIN"];
const ARB_TYPES = ["F-S", "F-F", "S-F", "S-S"];
const KINDS: SigKind[] = ["candle", "vol", "arb", "break", "candle", "vol"];

let sid = 0;

const pick = <T,>(arr: readonly T[]): T => arr[Math.floor(Math.random() * arr.length)];

function level(v: number): string {
  return Math.round(v / 50) * 50 >= 1000
    ? (Math.round(v / 50) * 50).toString().replace(/\B(?=(\d{3})+(?!\d))/g, "\u2009")
    : String(Math.round(v / 50) * 50);
}

function makeSig(): Sig {
  const coin = pick(COINS);
  const ex = pick(EXS);
  const kind = pick(KINDS);
  let text = "";
  switch (kind) {
    case "candle":
      text = `${coin} · открытие свечи ${pick(["1m", "5m"])} на ${ex}`;
      break;
    case "vol":
      text = `${coin} · аномальный объём +${Math.floor(180 + Math.random() * 260)}% на ${ex}`;
      break;
    case "arb":
      text = `${coin} · спред ${pick(ARB_TYPES)} ${ex}→${pick(EXS.filter((e) => e !== ex))} +${(
        0.08 +
        Math.random() * 0.5
      ).toFixed(2)}%`;
      break;
    case "break":
      text = `${coin} · пробой уровня ${level(60000 + Math.random() * 8000)} на ${ex}`;
      break;
  }
  return { id: ++sid, kind, text, time: "только что" };
}

const ICONS: Record<SigKind, { icon: React.ReactNode; cls: string }> = {
  candle: { icon: <BarChart3 className="h-3 w-3" />, cls: "text-violet-300" },
  vol: { icon: <Volume2 className="h-3 w-3" />, cls: "text-amber-300" },
  arb: { icon: <ArrowLeftRight className="h-3 w-3" />, cls: "text-cyan-300" },
  break: { icon: <TrendingUp className="h-3 w-3" />, cls: "text-emerald-400" },
};

const SEED_TIMES = ["1м назад", "48с назад", "31с назад", "17с назад", "6с назад"];

/* ФИКС hydration: Math.random() в ленивом инициализаторе useState давал РАЗНЫЙ
   HTML на сервере и клиенте → hydration mismatch. Теперь первый рендер
   детерминирован (SSR === клиент), а случайный контент подмешивается
   уже в useEffect — после гидратации. */
const SEED: Sig[] = [
  { id: -1, kind: "vol", text: "BTC · аномальный объём +214% на BINANCE", time: "1м назад" },
  { id: -2, kind: "arb", text: "ETH · спред F-F OKX→GATE +0.18%", time: "48с назад" },
  { id: -3, kind: "break", text: "SOL · пробой уровня 17 200 на BYBIT", time: "31с назад" },
  { id: -4, kind: "candle", text: "TON · открытие свечи 5m на OKX", time: "17с назад" },
  { id: -5, kind: "candle", text: "LINK · открытие свечи 1m на BITGET", time: "6с назад" },
];

function initial(): Sig[] {
  return SEED_TIMES.map((t, i) => {
    const s = makeSig();
    return { ...s, id: -(i + 1), time: t };
  });
}

function SigItem({ sig }: { sig: Sig }) {
  const { icon, cls } = ICONS[sig.kind];
  return (
    <span className="inline-flex items-center gap-1.5 whitespace-nowrap">
      <span className={cls}>{icon}</span>
      <span className="text-slate-300">{sig.text}</span>
      <span className="text-slate-600">— {sig.time}</span>
      <span className="mx-4 text-slate-700">·</span>
    </span>
  );
}

export function SignalStream() {
  const [sigs, setSigs] = useState<Sig[]>(SEED);

  useEffect(() => {
    /* после гидратации заменяем детерминированный сид живым контентом
       (асинхронно — чтобы не триггерить каскадный ререндер в теле эффекта) */
    const swap = setTimeout(() => setSigs(initial()), 0);
    const id = setInterval(() => {
      setSigs((prev) => [makeSig(), ...prev].slice(0, 7));
    }, 4200);
    return () => {
      clearTimeout(swap);
      clearInterval(id);
    };
  }, []);

  return (
    <div
      className="cp-signal-bar cp-marquee cp-mask-x mt-2 overflow-hidden border-t border-white/5 pt-1.5"
      aria-label="Поток сигналов"
    >
      <div
        className="cp-marquee-track font-mono text-[10.5px]"
        style={{ "--cp-marquee-duration": "26s" } as React.CSSProperties}
      >
        <div className="flex items-center" aria-hidden="true">
          {sigs.map((s) => (
            <SigItem key={s.id} sig={s} />
          ))}
        </div>
        <div className="flex items-center" aria-hidden="true">
          {sigs.map((s) => (
            <SigItem key={`d-${s.id}`} sig={s} />
          ))}
        </div>
      </div>
    </div>
  );
}
