"use client";

import { useEffect, useId, useRef, useState } from "react";
import { Mail, Lock, User, Eye, EyeOff, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useLatency } from "@/hooks/use-latency";

type Mode = "login" | "register";

interface Errors {
  name?: string;
  email?: string;
  password?: string;
}

const inputBase =
  "w-full bg-transparent text-sm text-slate-100 outline-none placeholder:text-slate-600";

function Field({
  label,
  icon,
  error,
  id,
  children,
}: {
  label: string;
  icon: React.ReactNode;
  error?: string;
  id: string;
  children: React.ReactNode;
}) {
  return (
    <div className="mb-3.5">
      <label htmlFor={id} className="mb-1.5 block text-xs font-medium text-slate-400">
        {label}
      </label>
      <div
        className={`group relative flex h-11 items-center gap-3 rounded-xl border bg-white/[0.04] px-3.5 transition-colors focus-within:bg-violet-500/[0.07] ${
          error
            ? "border-rose-400/50 focus-within:border-rose-400/70"
            : "border-white/10 focus-within:border-violet-400/60"
        }`}
      >
        <span
          className={`transition-colors group-focus-within:text-violet-300 ${
            error ? "text-rose-400/70" : "text-slate-500"
          }`}
        >
          {icon}
        </span>
        {children}
        {!error && (
          <span className="pointer-events-none absolute inset-x-0 -bottom-px h-0.5 origin-left scale-x-0 rounded bg-gradient-to-r from-violet-500 to-cyan-400 transition-transform duration-300 group-focus-within:scale-x-100" />
        )}
      </div>
      {error && (
        <p id={`${id}-err`} className="mt-1.5 flex items-center gap-1 text-[11px] text-rose-400" role="alert">
          {error}
        </p>
      )}
    </div>
  );
}

export function AuthCard() {
  const [mode, setMode] = useState<Mode>("login");
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [traders, setTraders] = useState(2480);
  const latency = useLatency();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errors, setErrors] = useState<Errors>({});
  const tiltRef = useRef<HTMLDivElement>(null);
  const nameId = useId();
  const emailId = useId();
  const pwId = useId();
  const { toast } = useToast();

  useEffect(() => {
    const id = setInterval(() => {
      setTraders((t) => Math.max(2400, t + Math.floor(Math.random() * 5) - 1));
    }, 5200);
    return () => clearInterval(id);
  }, []);

  /* деликатный 3D-наклон за курсором (только мышь) */
  useEffect(() => {
    const el = tiltRef.current;
    if (!el || !window.matchMedia("(pointer: fine)").matches) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const onMove = (e: MouseEvent) => {
      const r = el.getBoundingClientRect();
      const rx = ((e.clientY - r.top) / r.height - 0.5) * -2.2;
      const ry = ((e.clientX - r.left) / r.width - 0.5) * 2.2;
      el.style.transform = `perspective(900px) rotateX(${rx.toFixed(2)}deg) rotateY(${ry.toFixed(2)}deg)`;
    };
    const onLeave = () => {
      el.style.transform = "";
    };
    el.addEventListener("mousemove", onMove);
    el.addEventListener("mouseleave", onLeave);
    return () => {
      el.removeEventListener("mousemove", onMove);
      el.removeEventListener("mouseleave", onLeave);
    };
  }, []);

  const validate = (): Errors => {
    const e: Errors = {};
    const emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    if (!email.trim()) e.email = "Введите email";
    else if (!emailOk) e.email = "Похоже, в адресе опечатка";
    if (password.length < 8) e.password = "Минимум 8 символов";
    if (mode === "register" && name.trim().length < 2) e.name = "Как к вам обращаться?";
    return e;
  };

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (loading) return;
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length > 0) {
      toast({
        variant: "destructive",
        title: "Проверьте поля",
        description: "Некоторые данные заполнены некорректно.",
      });
      return;
    }
    setLoading(true);
    const isRegister = mode === "register";
    setTimeout(() => {
      setLoading(false);
      toast({
        title: isRegister ? "Аккаунт создан" : "Добро пожаловать",
        description: "Демо-режим: данные никуда не отправляются.",
      });
      setName("");
      setEmail("");
      setPassword("");
      setErrors({});
    }, 1100);
  };

  const isLogin = mode === "login";

  return (
    <div
      ref={tiltRef}
      className="sticky top-6 transition-transform duration-200 will-change-transform"
    >
      <div className="cp-border-spin rounded-[1.45rem] p-px shadow-[0_30px_80px_rgba(0,0,0,0.55)]">
        <aside
          className="cp-auth-compact rounded-[1.4rem] bg-gradient-to-b from-[#0d1022]/95 to-[#0a0c1e]/95 p-6 backdrop-blur-2xl"
          aria-label="Форма авторизации"
        >
          {/* Переключатель с бегунком */}
          <div className="relative mb-5 grid grid-cols-2 rounded-xl border border-white/10 bg-white/5 p-1">
            <span
              aria-hidden="true"
              className={`absolute inset-y-1 left-1 w-[calc(50%-4px)] rounded-lg bg-gradient-to-r from-violet-500 to-violet-700 shadow-lg shadow-violet-900/50 transition-transform duration-300 ${
                mode === "register" ? "translate-x-full" : "translate-x-0"
              }`}
            />
            <button
              type="button"
              onClick={() => {
                setMode("login");
                setErrors({});
              }}
              aria-pressed={isLogin}
              className={`relative z-10 rounded-lg py-2 text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-violet-400/70 ${
                isLogin ? "text-white" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              Вход
            </button>
            <button
              type="button"
              onClick={() => {
                setMode("register");
                setErrors({});
              }}
              aria-pressed={!isLogin}
              className={`relative z-10 rounded-lg py-2 text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-violet-400/70 ${
                !isLogin ? "text-white" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              Регистрация
            </button>
          </div>

          <h2 className="text-xl font-extrabold">
            {isLogin ? "С возвращением" : "Присоединяйтесь"}
          </h2>
          <p className="mb-5 mt-1 text-[13px] text-slate-400">
            {isLogin
              ? "Войдите, чтобы продолжить скрининг"
              : "Займёт меньше минуты — и весь рынок на одном экране"}
          </p>

          <form onSubmit={onSubmit} noValidate>
            {mode === "register" && (
              <Field label="Имя или ник" icon={<User className="h-4 w-4" />} error={errors.name} id={nameId}>
                <input
                  id={nameId}
                  type="text"
                  placeholder="Satoshi"
                  className={inputBase}
                  value={name}
                  aria-invalid={!!errors.name}
                  aria-describedby={errors.name ? `${nameId}-err` : undefined}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (errors.name) setErrors((p) => ({ ...p, name: undefined }));
                  }}
                  autoComplete="nickname"
                />
              </Field>
            )}
            <Field label="Email" icon={<Mail className="h-4 w-4" />} error={errors.email} id={emailId}>
              <input
                id={emailId}
                type="email"
                placeholder="you@example.com"
                className={inputBase}
                value={email}
                aria-invalid={!!errors.email}
                aria-describedby={errors.email ? `${emailId}-err` : undefined}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (errors.email) setErrors((p) => ({ ...p, email: undefined }));
                }}
                autoComplete="email"
              />
            </Field>
            <Field label="Пароль" icon={<Lock className="h-4 w-4" />} error={errors.password} id={pwId}>
              <input
                id={pwId}
                type={showPw ? "text" : "password"}
                placeholder="Минимум 8 символов"
                className={inputBase}
                value={password}
                aria-invalid={!!errors.password}
                aria-describedby={errors.password ? `${pwId}-err` : undefined}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (errors.password) setErrors((p) => ({ ...p, password: undefined }));
                }}
                autoComplete={isLogin ? "current-password" : "new-password"}
              />
              <button
                type="button"
                onClick={() => setShowPw((v) => !v)}
                aria-label={showPw ? "Скрыть пароль" : "Показать пароль"}
                className="rounded-md p-1 text-slate-500 transition-colors hover:text-slate-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-400/70"
              >
                {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </Field>

            <div className="mb-4 mt-1 flex items-center justify-between text-xs">
              <label className="flex cursor-pointer items-center gap-2 text-slate-400">
                <input
                  type="checkbox"
                  defaultChecked
                  className="h-3.5 w-3.5 cursor-pointer accent-violet-500"
                />
                Запомнить меня
              </label>
              <button
                type="button"
                onClick={() =>
                  toast({
                    title: "Восстановление пароля",
                    description: "Демо-режим: сброс пароля недоступен.",
                  })
                }
                className="rounded text-violet-300 transition-colors hover:text-violet-200 hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-400/70"
              >
                Забыли пароль?
              </button>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="cp-sheen flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-violet-600 via-violet-700 to-violet-800 text-sm font-bold text-white shadow-xl shadow-violet-900/40 transition-all hover:-translate-y-0.5 hover:shadow-violet-900/60 active:translate-y-0 disabled:pointer-events-none disabled:saturate-50"
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Подключение к биржам…
                </>
              ) : isLogin ? (
                "Войти"
              ) : (
                "Создать аккаунт"
              )}
            </button>
          </form>

          {/* Доверие */}
          <div className="cp-auth-trust mt-5 border-t border-white/10 pt-4">
            <div className="flex items-center gap-3.5">
              <div className="flex -space-x-2">
                <span className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-[#0b0d1c] bg-gradient-to-br from-amber-400 to-red-500 text-[11px] font-bold text-white">
                  А
                </span>
                <span className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-[#0b0d1c] bg-gradient-to-br from-cyan-400 to-sky-500 text-[11px] font-bold text-white">
                  М
                </span>
                <span className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-[#0b0d1c] bg-gradient-to-br from-violet-400 to-fuchsia-500 text-[11px] font-bold text-white">
                  К
                </span>
                <span className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-[#0b0d1c] bg-gradient-to-br from-emerald-400 to-teal-500 text-[11px] font-bold text-white">
                  D
                </span>
                <span className="flex h-8 w-8 items-center justify-center rounded-full border-2 border-[#0b0d1c] bg-gradient-to-br from-rose-400 to-violet-500 text-[11px] font-bold text-white">
                  +
                </span>
              </div>
              <p className="text-xs text-slate-400">
                <span className="font-mono font-semibold text-slate-100">
                  {traders.toLocaleString("ru-RU")}
                </span>{" "}
                трейдеров уже в системе
              </p>
            </div>
            <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1.5 font-mono text-[11px] text-slate-500">
              <span className="flex items-center gap-1.5">
                <i className="cp-dot-blink h-1.5 w-1.5 rounded-full bg-emerald-400" />
                Все 8 бирж онлайн
              </span>
              <span className="flex items-center gap-1.5">
                <i className="cp-dot-blink h-1.5 w-1.5 rounded-full bg-emerald-400" />
                задержка {latency} мс
              </span>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
