"use client";

import { useEffect, useRef, useState } from "react";
import { fmtPrice } from "./ticker-tape";
import { SignalStream } from "./signal-stream";

interface Candle {
  o: number;
  h: number;
  l: number;
  c: number;
  v: number;
}

const MAX_CANDLES = 52;
const TFS = ["1m", "5m", "15m", "1h"] as const;
type TF = (typeof TFS)[number];

const TF_VOL: Record<TF, number> = { "1m": 260, "5m": 420, "15m": 640, "1h": 900 };
const TF_MIN: Record<TF, number> = { "1m": 1, "5m": 5, "15m": 15, "1h": 60 };

function seededCandles(price: number, vol: number): Candle[] {
  const out: Candle[] = [];
  let p = 0;
  for (let i = 0; i < MAX_CANDLES; i++) {
    const o = p;
    const c = o + (Math.random() - 0.46) * vol;
    const h = Math.max(o, c) + Math.random() * vol * 0.5;
    const l = Math.min(o, c) - Math.random() * vol * 0.5;
    out.push({ o, h, l, c, v: 0.3 + Math.random() * 0.7 });
    p = c;
  }
  /* сдвигаем ряд так, чтобы цена последней свечи точно равнялась якорю:
     тот же инструмент → цена непрерывна при смене таймфрейма */
  const shift = price - out[out.length - 1].c;
  for (const k of out) {
    k.o += shift;
    k.h += shift;
    k.l += shift;
    k.c += shift;
  }
  return out;
}

function ema(values: number[], period: number): number[] {
  const k = 2 / (period + 1);
  const out: number[] = [];
  let prev = values[0] ?? 0;
  values.forEach((v, i) => {
    prev = i === 0 ? v : v * k + prev * (1 - k);
    out.push(prev);
  });
  return out;
}

function tfLabel(minutes: number): string {
  if (minutes >= 60) {
    const h = minutes / 60;
    return `-${h.toFixed(h % 1 ? 1 : 0)}h`;
  }
  return `-${minutes}m`;
}

export function LiveChart() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const tooltipRef = useRef<HTMLDivElement>(null);
  const priceRef = useRef<HTMLSpanElement>(null);
  const chgRef = useRef<HTMLSpanElement>(null);
  const dirRef = useRef<HTMLSpanElement>(null);
  const candlesRef = useRef<Candle[]>(seededCandles(67240, 260));
  const priceNum = useRef(67240);
  const mouseRef = useRef<{ x: number; y: number } | null>(null);
  const flashTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [tf, setTf] = useState<TF>("1m");

  /* Смена ТФ: цепляемся за ТЕКУЩУЮ цену, а не за базовую 67240,
     чтобы цена не прыгала при переключении таймфрейма.
     Заодно синхронизируем шапку (цена/Δ) сразу, не дожидаясь тика. */
  useEffect(() => {
    const base = priceNum.current;
    const candles = seededCandles(base, TF_VOL[tf]);
    candlesRef.current = candles;
    const last = candles[candles.length - 1];
    priceNum.current = last.c;
    const first = candles[0].o;
    const chg = ((last.c - first) / first) * 100;
    if (priceRef.current) priceRef.current.textContent = fmtPrice(last.c);
    if (chgRef.current) {
      chgRef.current.textContent = `${chg >= 0 ? "+" : ""}${chg.toFixed(2)}%`;
      chgRef.current.className = `rounded-md px-2 py-0.5 text-xs font-semibold font-mono ${
        chg >= 0 ? "bg-emerald-400/10 text-emerald-400" : "bg-rose-400/10 text-rose-400"
      }`;
    }
    if (dirRef.current) {
      dirRef.current.textContent = chg >= 0 ? "\u25B2" : "\u25BC";
      dirRef.current.className = `text-[10px] leading-none ${
        chg >= 0 ? "text-emerald-400" : "text-rose-400"
      }`;
    }
  }, [tf]);

  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    /* ФИКС: var(--font-…) НЕ работает в canvas ctx.font — парсер отклонял всю
       строку, и подписи рисовались дефолтным sans-serif. Берём реальное
       семейство из вычисленного стиля body (next/font отдаёт его через
       кастомное свойство). */
    const monoRaw = getComputedStyle(document.body)
      .getPropertyValue("--font-mono-cp")
      .trim();
    const mono = monoRaw || "ui-monospace, monospace";
    const monoFont = (px: number, bold = false) =>
      `${bold ? "bold " : ""}${px}px ${mono}, monospace`;

    let raf = 0;
    let W = 0;
    let H = 0;

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = wrap.clientWidth;
      H = wrap.clientHeight;
      canvas.width = W * dpr;
      canvas.height = H * dpr;
      canvas.style.width = `${W}px`;
      canvas.style.height = `${H}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const ro = new ResizeObserver(resize);
    ro.observe(wrap);
    resize();

    /* ---- геометрия ---- */
    const padR = 58;
    const padT = 10;
    const volH = Math.round(H * 0.12);
    const axisH = 12;
    const bottom = H - volH - axisH;
    const plotW = W - padR - 8;

    const draw = (t: number) => {
      const candles = candlesRef.current;
      const price = priceNum.current;
      ctx.clearRect(0, 0, W, H);

      let mn = Infinity;
      let mx = -Infinity;
      for (const c of candles) {
        mn = Math.min(mn, c.l);
        mx = Math.max(mx, c.h);
      }
      const range = mx - mn || 1;
      mn -= range * 0.08;
      mx += range * 0.08;
      const y = (v: number) => padT + (bottom - padT) * (1 - (v - mn) / (mx - mn));

      /* сетка + шкала цены */
      ctx.font = monoFont(10);
      ctx.textBaseline = "middle";
      for (let i = 0; i <= 4; i++) {
        const v = mn + ((mx - mn) * i) / 4;
        const yy = y(v);
        ctx.strokeStyle = "rgba(255,255,255,0.05)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(0, yy);
        ctx.lineTo(plotW, yy);
        ctx.stroke();
        ctx.fillStyle = "rgba(255,255,255,0.35)";
        ctx.fillText(fmtPrice(v), plotW + 8, yy);
      }

      const cw = plotW / candles.length;
      const maxV = Math.max(...candles.map((c) => c.v));

      /* объёмы */
      const volBase = H - axisH - 1;
      candles.forEach((c, i) => {
        const x = i * cw + cw / 2;
        const up = c.c >= c.o;
        const vh = (c.v / maxV) * volH;
        ctx.fillStyle = up ? "rgba(0,214,143,0.28)" : "rgba(255,77,106,0.28)";
        const bw = Math.max(2, cw * 0.6);
        ctx.fillRect(x - bw / 2, volBase - vh, bw, vh);
      });

      /* свечи */
      const mouse = mouseRef.current;
      const hoverIdx = mouse
        ? Math.max(0, Math.min(candles.length - 1, Math.floor(mouse.x / cw)))
        : -1;
      candles.forEach((c, i) => {
        const x = i * cw + cw / 2;
        const up = c.c >= c.o;
        const col = up ? "#00d68f" : "#ff4d6a";

        ctx.strokeStyle = col;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x, y(c.h));
        ctx.lineTo(x, y(c.l));
        ctx.stroke();

        const bw = Math.max(2, cw * 0.6);
        const yo = y(c.o);
        const yc = y(c.c);
        const top = Math.min(yo, yc);
        const hh = Math.max(1.2, Math.abs(yc - yo));
        if (i === candles.length - 1) {
          ctx.shadowColor = col;
          ctx.shadowBlur = 14;
        }
        ctx.fillStyle = col;
        ctx.globalAlpha = up ? 0.92 : 0.85;
        ctx.fillRect(x - bw / 2, top, bw, hh);
        ctx.shadowBlur = 0;
        ctx.globalAlpha = 1;

        if (i === hoverIdx) {
          ctx.strokeStyle = "rgba(255,255,255,0.45)";
          ctx.lineWidth = 1;
          ctx.strokeRect(x - bw / 2 - 1.5, top - 1.5, bw + 3, hh + 3);
        }
      });

      /* водяной знак пары */
      ctx.font = monoFont(11, true);
      ctx.textAlign = "center";
      ctx.fillStyle = "rgba(255,255,255,0.07)";
      ctx.fillText("BTC/USDT · PERP", plotW / 2, padT + 16);
      ctx.textAlign = "left";

      /* EMA-20 */
      const closes = candles.map((c) => c.c);
      const emaLine = ema(closes, 20);
      const grad = ctx.createLinearGradient(0, 0, plotW, 0);
      grad.addColorStop(0, "rgba(167,139,250,0.15)");
      grad.addColorStop(0.5, "rgba(167,139,250,0.85)");
      grad.addColorStop(1, "rgba(34,211,238,0.85)");
      ctx.strokeStyle = grad;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      emaLine.forEach((v, i) => {
        const x = i * cw + cw / 2;
        if (i === 0) ctx.moveTo(x, y(v));
        else ctx.lineTo(x, y(v));
      });
      ctx.stroke();

      /* ось времени */
      ctx.font = monoFont(9);
      ctx.fillStyle = "rgba(255,255,255,0.28)";
      ctx.textAlign = "center";
      for (let i = candles.length - 1; i >= 0; i -= 10) {
        const x = i * cw + cw / 2;
        const label =
          i === candles.length - 1 ? "сейчас" : tfLabel((candles.length - 1 - i) * TF_MIN[tf]);
        ctx.fillText(label, Math.min(x, plotW - 14), H - 4);
      }
      ctx.textAlign = "left";

      /* Y текущей цены (объявляем до перекрестия — тег перекрестия сверяется с ним) */
      const ly = Math.max(10, Math.min(bottom - 4, y(price)));

      /* перекрестие */
      if (mouse && hoverIdx >= 0) {
        const hx = hoverIdx * cw + cw / 2;
        ctx.setLineDash([3, 3]);
        ctx.strokeStyle = "rgba(255,255,255,0.25)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(hx, padT - 4);
        ctx.lineTo(hx, volBase + 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, mouse.y);
        ctx.lineTo(plotW, mouse.y);
        ctx.stroke();
        ctx.setLineDash([]);

        if (mouse.y >= padT && mouse.y <= bottom) {
          const mv = mn + (1 - (mouse.y - padT) / (bottom - padT)) * (mx - mn);
          /* тег перекрестия не наезжает на тег текущей цены */
          let tagY = mouse.y;
          if (Math.abs(tagY - ly) < 22) tagY = ly + (tagY >= ly ? 22 : -22);
          tagY = Math.max(padT + 8, Math.min(bottom - 8, tagY));
          ctx.fillStyle = "rgba(30,32,54,0.95)";
          ctx.beginPath();
          ctx.roundRect(plotW + 3, tagY - 8, padR - 10, 16, 4);
          ctx.fill();
          ctx.strokeStyle = "rgba(167,139,250,0.5)";
          ctx.stroke();
          ctx.fillStyle = "#cdd3ff";
          ctx.font = monoFont(9.5, true);
          ctx.fillText(fmtPrice(mv), plotW + 8, tagY + 1);
        }
      }

      /* линия текущей цены + пульс */
      ctx.setLineDash([4, 4]);
      ctx.strokeStyle = "rgba(167,139,250,0.6)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, ly);
      ctx.lineTo(plotW, ly);
      ctx.stroke();
      ctx.setLineDash([]);

      const p = reduced ? 0.5 : (t / 900) % 1;
      ctx.beginPath();
      ctx.arc(plotW, ly, 3.2, 0, Math.PI * 2);
      ctx.fillStyle = "#a78bfa";
      ctx.fill();
      if (!reduced) {
        ctx.beginPath();
        ctx.arc(plotW, ly, 3.2 + 9 * p, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(167,139,250,${0.5 * (1 - p)})`;
        ctx.stroke();
      }

      ctx.fillStyle = "#6d28d9";
      ctx.beginPath();
      ctx.roundRect(plotW + 3, ly - 9, padR - 10, 18, 4);
      ctx.fill();
      ctx.fillStyle = "#ffffff";
      ctx.font = monoFont(10, true);
      ctx.fillText(fmtPrice(price), plotW + 8, ly + 1);

      raf = requestAnimationFrame(draw);
    };

    raf = requestAnimationFrame(draw);

    /* ---- тултип OHLCV ---- */
    const onMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const yy = e.clientY - rect.top;
      if (x < 0 || x > plotW || yy < 0 || yy > H) {
        mouseRef.current = null;
        if (tooltipRef.current) tooltipRef.current.style.display = "none";
        return;
      }
      mouseRef.current = { x, y: yy };
      const candles = candlesRef.current;
      const cw = plotW / candles.length;
      const idx = Math.max(0, Math.min(candles.length - 1, Math.floor(x / cw)));
      const c = candles[idx];
      const tip = tooltipRef.current;
      if (!tip) return;
      const up = c.c >= c.o;
      const d = ((c.c - c.o) / c.o) * 100;
      const dCls = d >= 0 ? "text-emerald-400" : "text-rose-400";
      tip.innerHTML =
        `<div>O <span class="text-slate-100">${fmtPrice(c.o)}</span>&nbsp;&nbsp;H <span class="text-slate-100">${fmtPrice(c.h)}</span></div>` +
        `<div>L <span class="text-slate-100">${fmtPrice(c.l)}</span>&nbsp;&nbsp;C <span class="${up ? "text-emerald-400" : "text-rose-400"}">${fmtPrice(c.c)}</span></div>` +
        `<div>Vol <span class="text-slate-100">${c.v.toFixed(2)}</span>&nbsp;&nbsp;Δ <span class="${dCls}">${d >= 0 ? "+" : ""}${d.toFixed(2)}%</span></div>`;
      tip.style.display = "block";
      tip.style.left = `${Math.min(x + 14, plotW - 128)}px`;
      tip.style.top = "8px";
    };
    const onLeave = () => {
      mouseRef.current = null;
      if (tooltipRef.current) tooltipRef.current.style.display = "none";
    };

    canvas.addEventListener("mousemove", onMove);
    canvas.addEventListener("mouseleave", onLeave);

    /* ---- тики цены ---- */
    const tick = setInterval(() => {
      const candles = candlesRef.current;
      const last = candles[candles.length - 1];
      const prev = last.c;
      last.c += (Math.random() - 0.5) * TF_VOL[tf] * 0.16;
      last.h = Math.max(last.h, last.c);
      last.l = Math.min(last.l, last.c);
      last.v = Math.min(1, last.v + Math.random() * 0.05);
      priceNum.current = last.c;

      const first = candles[0].o;
      const chg = ((last.c - first) / first) * 100;
      if (priceRef.current) {
        priceRef.current.textContent = fmtPrice(last.c);
        const cls = last.c >= prev ? "cp-flash-up" : "cp-flash-down";
        priceRef.current.classList.remove("cp-flash-up", "cp-flash-down");
        void priceRef.current.offsetWidth;
        priceRef.current.classList.add(cls);
        if (flashTimer.current) clearTimeout(flashTimer.current);
        flashTimer.current = setTimeout(() => {
          priceRef.current?.classList.remove("cp-flash-up", "cp-flash-down");
        }, 600);
      }
      if (chgRef.current) {
        chgRef.current.textContent = `${chg >= 0 ? "+" : ""}${chg.toFixed(2)}%`;
        chgRef.current.className = `rounded-md px-2 py-0.5 text-xs font-semibold font-mono ${
          chg >= 0
            ? "bg-emerald-400/10 text-emerald-400"
            : "bg-rose-400/10 text-rose-400"
        }`;
      }
      if (dirRef.current) {
        dirRef.current.textContent = last.c >= prev ? "\u25B2" : "\u25BC";
        dirRef.current.className = `text-[10px] leading-none ${
          last.c >= prev ? "text-emerald-400" : "text-rose-400"
        }`;
      }
    }, 620);

    const step = setInterval(() => {
      const candles = candlesRef.current;
      const vol = TF_VOL[tf];
      const o = priceNum.current;
      const c = o + (Math.random() - 0.47) * vol * 0.9;
      candles.push({
        o,
        c,
        h: Math.max(o, c) + Math.random() * vol * 0.4,
        l: Math.min(o, c) - Math.random() * vol * 0.4,
        v: 0.3 + Math.random() * 0.7,
      });
      priceNum.current = c;
      if (candles.length > MAX_CANDLES) candles.shift();
    }, 3800);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      clearInterval(tick);
      clearInterval(step);
      canvas.removeEventListener("mousemove", onMove);
      canvas.removeEventListener("mouseleave", onLeave);
      if (flashTimer.current) clearTimeout(flashTimer.current);
    };
  }, [tf]);

  return (
    <div className="group rounded-2xl border border-white/10 bg-white/[0.04] p-3.5 backdrop-blur-xl transition-[border-color,box-shadow] duration-300 hover:border-violet-500/40 hover:shadow-[0_18px_50px_-16px_rgba(139,92,246,0.45)] sm:p-4">
      <div className="mb-2.5 flex flex-wrap items-center justify-between gap-x-3 gap-y-2">
        <div className="flex items-center gap-2.5 text-sm font-bold">
          <span className="cp-dot-live h-2 w-2 rounded-full bg-emerald-400" />
          BTC/USDT
          <span className="font-mono text-[11px] font-medium text-slate-400">{tf}</span>
          <span className="hidden font-mono text-[10px] text-slate-500 sm:inline">EMA 20</span>
          <span className="hidden h-0.5 w-4 rounded bg-gradient-to-r from-violet-400 to-cyan-400 sm:inline-block" />
        </div>
        <div className="flex items-center gap-1 rounded-lg border border-white/10 bg-white/5 p-0.5">
          {TFS.map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTf(t)}
              aria-pressed={tf === t}
              className={`rounded-md px-2.5 py-1 font-mono text-[11px] font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-400/70 ${
                tf === t
                  ? "bg-violet-500/30 text-white"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2 font-mono">
          <span ref={dirRef} aria-hidden="true" className="text-[10px] leading-none text-emerald-400">
            ▲
          </span>
          <span
            ref={priceRef}
            className="rounded-md px-1.5 text-base font-bold tabular-nums transition-colors"
          >
            67 240
          </span>
          <span
            ref={chgRef}
            className="rounded-md bg-emerald-400/10 px-2 py-0.5 text-xs font-semibold text-emerald-400"
          >
            +1.24%
          </span>
        </div>
      </div>
      <div ref={wrapRef} className="cp-chart-box relative h-40 w-full sm:h-44">
        <canvas
          ref={canvasRef}
          className="absolute inset-0 cursor-crosshair"
          aria-label="Живой график BTC/USDT"
        />
        <div
          ref={tooltipRef}
          aria-hidden="true"
          className="pointer-events-none absolute left-2 top-2 z-20 hidden rounded-lg border border-white/10 bg-[#0b0d1f]/95 px-2.5 py-2 font-mono text-[10px] leading-relaxed text-slate-400 backdrop-blur-md"
        />
      </div>
      <SignalStream />
    </div>
  );
}
