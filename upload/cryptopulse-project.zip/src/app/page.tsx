import { Zap } from "lucide-react";
import { Starfield } from "@/components/cryptopulse/starfield";
import { TickerTape } from "@/components/cryptopulse/ticker-tape";
import { LiveChart } from "@/components/cryptopulse/live-chart";
import { FeatureTiles, ExchangeMarquee } from "@/components/cryptopulse/features";
import { AuthCard } from "@/components/cryptopulse/auth-card";
import { LiveStatusChip } from "@/components/cryptopulse/live-status-chip";

export default function Home() {
  return (
    <div className="relative flex min-h-dvh flex-col overflow-x-clip bg-[#05060f] text-slate-100">
      <Starfield />
      <div aria-hidden="true" className="cp-grid-overlay fixed inset-0 z-0 pointer-events-none" />

      <TickerTape />

      <main className="cp-page-main relative z-10 mx-auto flex w-full max-w-6xl flex-1 flex-col justify-center px-6 py-7 sm:py-8">
        <div className="grid items-center gap-9 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,0.85fr)] lg:gap-12">
          {/* Левая колонка */}
          <section aria-label="О продукте" className="min-w-0">
            <div className="cp-fade-up flex items-center gap-3">
              <span className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-violet-500 to-violet-800 shadow-lg shadow-violet-900/50">
                <span aria-hidden="true" className="cp-logo-ring" />
                <Zap className="h-4.5 w-4.5 text-white" fill="currentColor" />
              </span>
              <div className="leading-tight">
                <div className="text-[15px] font-extrabold tracking-wide">CRYPTOPULSE</div>
                <div className="text-[9px] font-semibold tracking-[0.34em] text-slate-500">
                  SCREENER PRO
                </div>
              </div>
              <LiveStatusChip />
            </div>

            <h1 className="cp-hero-h1 cp-fade-up mt-5 text-[clamp(1.75rem,3.8vw,2.6rem)] font-extrabold leading-[1.12] tracking-tight">
              Рынок не спит.
              <br />
              <span className="cp-gradient-text">Мы — тоже.</span>
            </h1>
            <p className="cp-hero-sub cp-fade-up mt-3 max-w-[32rem] text-sm leading-relaxed text-slate-400 sm:text-[15px]">
              Плотность, свечные паттерны, межбиржевой арбитраж и новости с 8 бирж —
              в одном экране. Данные приходят быстрее, чем закроется свеча.
            </p>

            <div className="cp-chart-card cp-fade-up mt-5">
              <LiveChart />
            </div>

            <div className="mt-3">
              <FeatureTiles />
            </div>
          </section>

          {/* Правая колонка — форма */}
          <div className="min-w-0 pb-1">
            <AuthCard />
          </div>
        </div>
      </main>

      <ExchangeMarquee />

      <footer className="relative z-10 mt-auto border-t border-white/10 py-3.5 text-center text-xs text-slate-600">
        © 2026 CryptoPulse · Screener Pro — демо-режим, данные генерируются локально
      </footer>
    </div>
  );
}
