import type { Metadata, Viewport } from "next";
import { Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({
  variable: "--font-sans-cp",
  subsets: ["latin", "cyrillic"],
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-mono-cp",
  subsets: ["latin", "cyrillic"],
  display: "swap",
});

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  themeColor: "#05060f",
};

export const metadata: Metadata = {
  title: "CryptoPulse — Screener Pro",
  description:
    "Плотность, свечные паттерны, межбиржевой арбитраж и новости с 8 бирж — в одном экране. Рынок не спит. Мы — тоже.",
  keywords: ["CryptoPulse", "скринер", "криптовалюты", "арбитраж", "трейдинг"],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "CryptoPulse — Screener Pro",
    description:
      "Плотность, свечные паттерны, межбиржевой арбитраж и новости с 8 бирж — в одном экране.",
    type: "website",
    locale: "ru_RU",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" suppressHydrationWarning className="dark">
      <body
        className={`${inter.variable} ${jetbrainsMono.variable} antialiased bg-background text-foreground font-sans`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
